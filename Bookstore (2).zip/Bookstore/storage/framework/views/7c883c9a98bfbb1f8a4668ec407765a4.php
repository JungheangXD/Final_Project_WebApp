<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank you</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}
.container1{
    width: 100%;
    height:100vh;
    background:#eee ;
    display: flex;
    align-items:center;
    justify-content:center;
}
.popup{
    width:300px;
    background:#fff;
    border: 2px solid #000;
    position:absolute;
    top:50%;
    left:50%;
    transform: translate(-50%,-50%);
    text-align:center;
    padding: 0 30px 30px;
    color:#333;
}
.popup img{
    width: 35px;
    margin-top:20px ;
    border-radius: 50%;
}
.popup h2{
    font-size: 28px;
    font-weight: 500;
    margin:5px 0 3px;
}

.popup button{
    width:80px;
    margin-top: 10px;
    padding: 8px;
    background:#6fd649;
    color:#fff;
    outline:none;
    font-size: 18px;
    box-shadow: 0 5px 5px rgba(0,0,0,0.2);
    cursor: pointer;
}
    </style>
</head>
<body>
    <div class="container1">
        <div class="popup">
            <img src="public/image/emoji.jpg" alt="">
            <h2>Thank you!</h2>
            <p>Your order is successfully</p>
            <a href="<?php echo e(route('welcome')); ?>"><button type="button">ok</button></a>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\nita\Documents\term4\web application\Bookstore\resources\views/displaypopup.blade.php ENDPATH**/ ?>