<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link ref="stylesheet" href="public/app.css">
    <style>
body .container{
  font-family: 'Poppins' , sans-serif;
  margin: 0;
  padding:0;
  box-sizing: border-box;
  outline:none;
  border:none;
  text-decoration: none;
  text-transform: uppercase;
}
.container{
  min-height:100vh;
  background-color: #eee;
  display:flex;
  align-items:center;
  justify-content: center;
  flex-flow: column;
  padding-bottom:60px;
}
.container form{
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 10px 15px rgb(0, 0 , 0 ,.1);
  padding: 20px;
  width:400px;
}
.container form .inputbox{
margin-top: 20px;

}
.container form .inputbox span{
  display:block;
  color:#669007;
  padding-bottom: 5px;
}
.container form .inputbox input,
.container form .inputbox select{
    width:100px;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid rgba(0,0,0,.3);
    color:#444;
}
.container form .flexbox{
    display: flex;
    gap:10px;
}
.container form .flexbox .inputbox{
    flex:1 1 150px;
}
.container form .submit-btn{
    width: 100%;
    background-color:linear-gradient(45deg , blueviolet , deeppink);
    margin-top: 20px;
    padding: 10px;
    font-size:20px;
    color: #669007;
    cursor:pointer;
    transition: .2s linear;
}
    </style>
</head>
<body>
    <div class="container">
        <form action="<?php echo e(route('displaypopup')); ?>" >
            <div class="inputbox">
                <span>card number</span>
                <input type="text" maxlength= "16" class="card-number-input" placeholder="Card number" required style=" width:350px;">
            </div>
            <div class="inputbox">
                <span>card holder</span>
                <input type="text" maxlength= "16" class="card-holder-input" placeholder="Card holder" required style=" width:350px;">
            </div>
            <div class="flexbox">
                <div class="inputbox">
                    <span>expiration mm</span>
                        <select name="" class="month-input" placeholder="" required>
                            <option value="month" selected disabled>month</option>
                            <option value="01" >01</option>
                            <option value="02" >02</option>
                            <option value="03" >03</option>
                            <option value="04" >04</option>
                            <option value="05" >05</option>
                            <option value="06" >06</option>
                            <option value="07" >07</option>
                            <option value="08" >08</option>
                            <option value="09" >09</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                        </select>
                </div>
                <div class="inputbox">
                    <span>expiration yy</span>
                        <select name="" id="" class="year-input">
                            <option value="year" selected disabled>year</option>
                            <option value="2021" >2021</option>
                            <option value="2022" >2022</option>
                            <option value="2023" >2023</option>
                            <option value="2024" >2024</option>
                            <option value="2025" >2025</option>
                            <option value="2026" >2026</option>
                            <option value="2027" >2027</option>
                            <option value="2028" >2028</option>
                            <option value="2029" >2029</option>
                            <option value="2030" >2030</option>
                        </select>
                </div>
                <div class="inputbox">
                    <span>cvv</span>
                        <input type="text" maxlength="4" class="cvv-input">
                </div>
            </div>
            <input type="submit" value="comfirm" class="submit-btn">
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\nita\Documents\term4\web application\Bookstore\resources\views/payment.blade.php ENDPATH**/ ?>