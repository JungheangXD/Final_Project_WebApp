<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Shop Web Page</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('app.css')); ?>">
    <script src="<?php echo e(asset('app.js')); ?>"></script>

</head>
<body>
<header>
    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>
    <a href="#" class="logo">Book Shop<span>.</span></a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="#product">products</a>
        <a href="#contact">contact</a>
    </nav>

    <div class="icons">
        <a href="" class="fas fa-star"></a>
        <a href="<?php echo e(route('register')); ?>" class="fas fa-user"></a>
        <a href="<?php echo e(route('shoppingcart')); ?> " class ="fa-solid fa-cart-shopping" id="cart-icon"></a>
        <div class="cart">
            <h2 class="cart-title">Your Cart</h2>
            <div class="cart-content">

            </div>
            <!-- total -->
            <div class="total">
                <div class="total-title">Total</div>
                <div class="total-price">$0</div>
            </div>
            <!-- Buy button -->
            <a href="Registerweb.blade.php"><button type="button" class="btn-buy">Buy Now</button></a>
            <!-- cart close -->
            <i class="fa-regular fa-x" id="close-cart"></i>
        </div>
    </div>
    <!-- add cart -->


</header>

<!-- home section startz; -->

<section class="home" id="home">
    <div class="content">
        <h3>Today</h3>
        <span>is a Reader</span>
        <h5>Tomorrow</h5>
        <span>is a Leader</span><br>
        <a href="#product" class="shop">Shop Now</a>
    </div>
</section>
<!-- home section end -->

<!-- product section  -->

<section class="product" id="product">
    <h1 class="heading">Books Collection</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img class="images" src="/image/book.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">I am the hero of my on left</h3>
                <div class="price">10$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book1.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">The strength in our scars</h3>
                <div class="price">9$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book8.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">Life after college</h3>
                <div class="price">15$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book3.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">The little book of seft care</h3>
                <div class="price">5$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book4.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">1047 Reason to smile</h3>
                <div class="price">7$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book5.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">Know your self</h3>
                <div class="price">7$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book6.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">The little book of life hacks</h3>
                <div class="price">10$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book7.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">Anxiety of happens</h3>
                <div class="price">11$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book10.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">Anxiety of happens</h3>
                <div class="price">11$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book11.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">broke milennial</h3>
                <div class="price">11$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book12.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">Finish School</h3>
                <div class="price">11$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book13.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <i class="cart-btn1">add to cart</i>
                </div>
            </div>
            <div class="content">
                <h3 class="product-content">Joy Ful</h3>
                <div class="price">11$</div>
            </div>
        </div>
    </div>
</section>
<!--end of product section  -->
<!-- start about us -->
<section class="about" id="about">
    <div class="contents">
        <h4>our service</h4>
        <p>We are a team of passionate people whose goal is to improve everyone's life through disruptive products. We build great products to solve your business problems.
            Our products are designed for small to medium size companies willing to optimize their performance.</p>
        <span>Follow us</span>
        <div class="icon">
            <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#"><i class="fa-brands fa-youtube"></i></a>
            <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
            <a href="#"><i class="fa-brands fa-twitter"></i></a>
        </div>
    </div>
</section>
<section style="padding-top: 100px; margin-top: -100px" id="contact">
</section>

</body>
</html>
<?php /**PATH C:\Users\Chungheang\Desktop\Bookstore\resources\views/welcome.blade.php ENDPATH**/ ?>