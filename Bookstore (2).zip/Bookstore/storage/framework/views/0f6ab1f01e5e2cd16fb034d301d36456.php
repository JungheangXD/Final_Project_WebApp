<!DOCTYPE html>
<html lang="en">
<head>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="CodeHim">
    <title>Happy Shopping with US ! </title>

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">


</head>
<body>
<header class="intro">

    <div class="action">
        <a href="<?php echo e(route('welcome')); ?>"><i class="fas fa-home"></i> HomePage</a>

    </div>
</header>


<main>
    <!-- Start DEMO HTML (Use the following code into your project)-->
    <header id="site-header">
        <div class="container">
            <h1>Your Shopping Cart</h1>
        </div>
    </header>

    <div class="container">

        <section id="cart">
            <article class="product">
                <header>
                    <a class="remove">
                        <img src="/image/book1.jpg" alt="">

                        <h3>Remove product</h3>
                    </a>
                </header>

                <div class="content">

                    <h1>The Strength in our scars</h1>

                    The strength in our scars is Bianca Sparacino's reminder to you: No matter what you're going through, no matter where you are on your healing journey-you are strong. Through poetry, prose, and the compassionate encouragement you would expect from someone who knows exactly what you're working through.


                </div>

                <footer class="content">
                    <span class="qt-minus">-</span>
                    <span class="qt">2</span>
                    <span class="qt-plus">+</span>

                    <h2 class="full-price">
                        29.98€
                    </h2>

                    <h2 class="price">
                        14.99€
                    </h2>
                </footer>
            </article>

            <article class="product">
                <header>
                    <a class="remove">
                        <img src="/image/book4.jpg" alt="">

                        <h3>Remove product</h3>
                    </a>
                </header>

                <div class="content">

                    <h1>1,047 Reasons to SMILE</h1>

                    Smiling has been shown to relieve stress, boost the immune system, release endorphins, and even make us more attractive. It's the natural drug.

                </div>

                <footer class="content">

                    <span class="qt-minus">-</span>
                    <span class="qt">1</span>
                    <span class="qt-plus">+</span>

                    <h2 class="full-price">
                        79.99€
                    </h2>

                    <h2 class="price">
                        79.99€
                    </h2>
                </footer>
            </article>

            <article class="product">
                <header>
                    <a class="remove">
                        <img src="/image/book5.jpg" alt="">

                        <h3>Remove product</h3>
                    </a>
                </header>

                <div class="content">

                    <h1>Know yourself</h1>

                    Incisive questions can inspire self-reflection, spark ideas, and, best of all, reveal surprising truths.

                </div>

                <footer class="content">

                    <span class="qt-minus">-</span>
                    <span class="qt">3</span>
                    <span class="qt-plus">+</span>

                    <h2 class="full-price">
                        53.99€
                    </h2>

                    <h2 class="price">
                        17.99€
                    </h2>
                </footer>
            </article>

        </section>

    </div>

    <footer id="site-footer">
        <div class="container clearfix">

            <div class="left">
                <h2 class="subtotal">Subtotal: <span>163.96</span>€</h2>
                <h3 class="tax">Taxes (5%): <span>8.2</span>€</h3>
                <h3 class="shipping">Shipping: <span>5.00</span>€</h3>
            </div>

            <div class="right">
                <h1 class="total">Total: <span>177.16</span>€</h1>
                <a class="btn">Checkout</a>
            </div>

        </div>
    </footer>
</main>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="<?php echo e(asset('/js/script.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\Chungheang\Desktop\Bookstore\resources\views/ShoppingCart.blade.php ENDPATH**/ ?>