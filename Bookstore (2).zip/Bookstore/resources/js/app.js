// //cart
// let cartIcon = document.querySelector('#cart-icon')
// let cart = document.querySelector('.cart')
// let closeCart = document.querySelector('#close-cart')
//
// // open cart
// cartIcon.onclick = () => {
//     cart.classList.add("active");
// };
// // close cart
// closeCart.onclick = () => {
//     cart.classList.remove("active");
// };
//
// // cart working js
// if(document.readyState === 'loading'){
//     document.addEventListener('DOMContentLoaded' , ready)
// }else{
//     ready();
// }
//
// //Making Function
// function ready(){
//     //remove items from cart
//     var removeCartButtons = document.getElementsByClassName('cart-remove')
//     console.log(removeCartButtons)
//     for (var i = 0 ; i < removeCartButtons.length ; i++){
//         var button = removeCartButtons[i]
//         button.addEventListener('click' , removeCartItem)
//     }
//     // quantity change
//     var quantityInput = document.getElementsByClassName('cart-quantity')
//     for (var i = 0 ; i < quantityInput.length ; i++){
//         var input = quantityInput[i];
//         input.addEventListener('change' , quantitychanged);
//     }
//     //add to cart
//     var addCart = document.getElementsByClassName('cart-btn')
//     // console.log(addCart )
//     for (var i = 0 ; i < addCart.length ; i++){
//         var button = addCart[i];
//         button.addEventListener('click' , addCartClicked);
//     }
// //Buy Button work
//     document
//         .getElementsByClassName('btn-buy')[0]
//         .addEventListener("click", buyButtonClicked);
// }
//
// //Buy Button
// function buyButtonClicked(){
//     var cartcontent = document.getElementsByClassName('cart-content')[0]
//     while (cartcontent.hasChildNodes()){
//         cartcontent.removeChild(cartcontent.firstChild);
//     }
//     updatetotal();
// }
//
// //remove items from cart
// function removeCartItem(event){
//     var buttonClicked = event.target
//     buttonClicked.parentElement.remove();
//     updatetotal();
// }
// // quantity changes
// function quantitychanged(event){
//     var input = event.target
//     if(isNaN(input.value) || input.value <= 0){
//         input.value = 1;
//     }
//     updatetotal();
// }
// // add To cart
// function addCartClicked(event){
//     var button = event.target
//     var shop = button.parentElement
//     var title = shop.getElementsByClassName('product-content')[0].innerText;
//     var price = shop.getElementsByClassName('price')[0].innerText;
//     var productimage = shop.getElementsByClassName('images')[0].src;
//     addProductTocart(title , price , productimage);
//     updatetotal();
// }
// function addProductTocart(title , price , productimage){
//     var cartShopBox = document.createElement('div')
//     cartShopBox.classList.add('cart-box')
//     var cartItems = document.getElementsByClassName('cart-content')[0]
//     var cartItemsNames = cartItems.getElementsByClassName('cart-product-title')
//     for (var i = 0 ; i < cartItemsNames.length ; i++){
//         if (cartItemsNames[i].innerText === title){
//             alert("this item already choose");
//             return;
//         }
//     }
//     cartShopBox.innerHTML = `
//                     <img src="${productimage}" alt="" class="cart-img">
//                     <div class="detial-box">
//                         <div class="cart-product-title">${title}</div>
//                         <div class="cart-price">${price}</div>
//                         <input type="number" value="1" class="cart-quantity">
//                     </div>
//                     <i class=" cart-remove">Remove</i>`;
//     cartItems.append(cartShopBox);
//     cartShopBox
//         .getElementsByClassName('cart-remove')[0]
//         .addEventListener('Click' , removeCartItem);
//     cartShopBox
//         .getElementsByClassName('cart-quantity')[0]
//         .addEventListener('change' , quantitychanged);
// }
//
// //update total
// function updatetotal(){
//     var cartContent = document.getElementsByClassName('cart-content')[0];
//     var cartBoxes = cartContent.getElementsByClassName('cart-box');
//     var total = 0;
//     for (var i = 0 ; i < cartBoxes.length ; i++){
//         var cartBox = cartBoxes[i]
//         var priceElement = cartBox.getElementsByClassName('cart-price')[0];
//         var quantityElement = cartBox.getElementsByClassName('cart-quantity')[0];
//         var price = parseFloat(priceElement.innerText.replace("$", ""));
//         var quantity = quantityElement.value;
//         total = total +  price * quantity;
//     }
//     // if price contain some cents value
//     total = Math.round(total * 100) /  100;
//     document.getElementsByClassName("total-price")[0].innerText = "$" + total;
//
// }
// /* .cart-modal-overlay {
//   position: fixed;
//   top: 0;
//   left: 0;
//   width: 100%;
//   height: 100%;
//   background-color: rgba(0, 0, 0, .5);
//   z-index: 2;
//   transform: translateX(-200%);
//   transition: .5s ease-out;
//
// }
//
// .cart-modal {
//   height: 100vh;
//   width: 50%;
//   background-color: rgb(50,50,50);
//   float: right;
//   overflow: scroll;
//   overflow-x: hidden;
// }
//
// #close-btn {
//   font-size: 1.5rem;
//   float: right;
//   margin: .5em 2em 0 0;
//   color: white;
//   cursor: pointer;
// }
//
// .cart-is-empty {
//   color: white;
//   text-align: center;
//   font-size: 1.5rem;
//   margin-bottom: 1em;
//   display: none;
//
// }
//
// .total {
//   text-align: center;
//   margin: 2em 0 2em 0;
// /*   display: none; */
// /* }
//
// .cart-total {
//   color: white;
// }
//
// .total-price {
//   color: white;
//   font-size: 2rem;
//   display: block;
// }
//
// .purchase-btn {
//   font-size: 1rem;
//   font-weight: bolder;
//   background-color: green;
//   color: white;
//   padding: 1em 2em;
//   border-radius: 10px;
//   outline: none;
//   border: none;
//   cursor: pointer;
//   margin: 2em 0 1em 0;
// } */
//
// /* .product-rows {
//   margin-top: 3em;
//   width: 95%;
//   margin-left: auto;
//   margin-right: auto;
//
// }
//
// .product-row {
//   display: flex;
//   align-items: center;
// }
//
// .cart-image {
//   width: 10rem;
//   margin: 1em;
// }
//
// .cart-price {
//   color: white;
//   font-size: 1.5rem;
//   font-weight: bolder;
// }
//
// .product-quantity {
//   width: 4rem;
//   font-size: 2rem;
//   margin-left: 3rem;
// }
//
// .remove-btn {
//   padding: 1em 2em;
//   background-color: red;
//   color: white;
//   outline: none;
//   border: none;
//   cursor: pointer;
//   margin-left: 3rem;
//   font-weight: bolder;
//   font-size: 1rem;
// }
//
// .remove-btn:active {
//   transform: translateY(5px);
// } */
