<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="CodeHim">
    <title>Shop with US ! </title>

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">


</head>
<body>
<header class="intro">

    <div class="action">
        <a href="{{ route('welcome') }}"><i class="fas fa-home"></i> HomePage</a>

    </div>
</header>


<main>
    <!-- Start DEMO HTML (Use the following code into your project)-->
    <header id="site-header">
        <div class="container">
            <h1>Your Shopping Cart</h1>
        </div>
    </header>

    <div class="container">

        <div class="cart">
            <div class="product">
                <header>
                    <a class="remove">
                        <img src="/image/book1.jpg" alt="">

                        <h3>Remove product</h3>
                    </a>
                </header>

                <div class="content">

                    <h1>The Strength in our scars</h1>

                    <h5>The strength in our scars is Bianca Sparacino's reminder to you: No matter what you're going through, no matter where you are on your healing journey-you are strong.
                         Through poetry, prose, and the compassionate encouragement you would expect from someone who knows exactly what you're working through.</h5>
                </div>

                <footer class="content">
                    <!-- <span class="qt-minus">-</span> -->
                    <input class="qt" type="number" value="1">
                    <!-- <span class="qt-plus">+</span> -->

                    <h2 class="full-price">
                        14.99€
                    </h2>

                </footer>
            </div>

            <div class="product">
                <header>
                    <a class="remove">
                        <img src="/image/book4.jpg" alt="">

                        <h3>Remove product</h3>
                    </a>
                </header>

                <div class="content">

                    <h1>1,047 Reasons to SMILE</h1>

                    <h5>Smiling has been shown to relieve stress, boost the immune system, release endorphins, and even make us more attractive. 
                        It's the natural drug.</h5>

                </div>

                <footer class="content">

                    <!-- <span class="qt-minus">-</span> -->
                    <input class="qt" type="number" value="1">
                    <!-- <span class="qt-plus">+</span> -->

                    <h2 class="full-price">
                        79.99€
                    </h2>
                </footer>
            </div>

            <div class="product">
                <header>
                    <a class="remove">
                        <img src="/image/book5.jpg" alt="">

                        <h3>Remove product</h3>
                    </a>
                </header>

                <div class="content">

                    <h1>Know yourself</h1>

                    <h5>Incisive questions can inspire self-reflection, spark ideas, and, best of all, reveal surprising truths.</h5>

                </div>

                <footer class="content">

                    <!-- <span class="qt-minus">-</span> -->
                    <input class="qt" type="number" value="1">
                    <!-- <span class="qt-plus">+</span> -->

                    <h2 class="full-price">
                        17.99€
                    </h2>

                </footer>
            </div>

        </div>

    </div>

    <footer id="site-footer">
        <div class="container clearfix">

            <div class="left">
                <h2 class="subtotal">Subtotal: <span>163.96</span>€</h2>
                <h3 class="tax">Taxes (5%): <span>8.2</span>€</h3>
                <h3 class="shipping">Shipping: <span>5.00</span>€</h3>
            </div>

            <div class="right">
                <h1 class="total">Total: <span>177.16</span>€</h1>
                <input type="checkbox" id="click">
                <label for="click" class="btn" >Checkout</label>
                <div class="Content">
                    <div class="header">
                        <label for="click" class="fas fa-times"></label>
                    </div>
                    <!-- <label for="click" class="fas fa-check"></label> -->
                    <p>Have'nt got any account yet go to <a class="signup" href="{{ route('Registerweb') }}" >Signup Now</a></p>
                    <div class="line"></div>
                </div>

            </div>

        </div>
    </footer>
</main>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src="{{ asset('/js/script.js') }}" async></script>

</body>
</html>
