<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Shop Web Page</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('app.css') }}">
   
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/> -->

</head>
<body>
<header>
    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fas fa-bars"></label>
    <a href="#" class="logo">Book Shop<span>.</span></a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="#product">products</a>
        <a href="#contact">contact</a>
    </nav>

    <div class="icons">
        <a href="" class="fas fa-star"></a>
        <a href="{{ route('Registerweb') }}" class="fas fa-user"></a>
        <a href=" {{ route('shoppingcart') }}" class ="fa-solid fa-cart-shopping" id="cart-icon"></a>
        <div class="cart">
            <h2 class="cart-title">Your Cart</h2>
            <div class="cart-content">

            </div>
            <!-- total -->
            <div class="total">
                <div class="total-title">Total</div>
                <div class="total-price">$0</div>
            </div>
            <!-- Buy button -->
            <a href="Registerweb.blade.php"><button type="button" class="btn-buy">Buy Now</button></a>
            <!-- cart close -->
            <i class="fa-regular fa-x" id="close-cart"></i>
        </div>
    </div>
    <!-- add cart -->


</header>

<!-- home section startz; -->

<section class="home" id="home">
    <div class="content">
        <h3>Today</h3>
        <span>is a Reader</span>
        <h5>Tomorrow</h5>
        <span>is a Leader</span><br>
        <a href="#product" class="shop">Shop Now</a>
    </div>
</section>
<!-- home section end -->

<!-- new arrival section -->
<section class="new-arrival" id="new-arrival"> 
    <h3>New Arrivals</h3>
    <div class="Container">
        <div class="Wrapper">
            <i id="left" class=" fa-solid fa-angle-left"></i>
            <div class="carousel">
                <img src="/image/book13.jpg" alt="img" draggable="false">
                <img src="/image/book1.jpg" alt="img" draggable="false">
                <img src="/image/book14.jpg" alt="img" draggable="false">
                <img src="/image/book19.jpg" alt="img" draggable="false">
                <img src="/image/book21.jpg" alt="img" draggable="false">
                <img src="/image/book3.jpg" alt="img" draggable="false">
                <img src="/image/book5.jpg" alt="img" draggable="false">
                <img src="/image/book11.jpg" alt="img" draggable="false" >
                <img src="/image/book10.jpg" alt="img" draggable="false">
            </div>
            <i id="right" class=" fa-solid fa-angle-right"></i>
        </div>
    </div>
</section>
<!-- new arrival end -->

<!-- product section  -->
<section class="product" id="product">
    <h1 class="heading">Books Collection</h1>
    <div class="box-container">
        <div class="box">
            <div class="image">
                <img class="images" src="/image/book.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">I am the hero of my on left</span>
                <div class="price">10$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book1.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The strength in our scars</span>
                <div class="price">9$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book8.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Life after college</span>
                <div class="price">15$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book3.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The little book of seft care</span>
                <div class="price">5$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book4.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">1047 Reason to smile</span>
                <div class="price">7$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book5.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Know your self</span>
                <div class="price">7$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book6.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The little book of life hacks</span>
                <div class="price">10$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book7.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Anxiety of happens</span>
                <div class="price">11$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book10.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Anxiety of happens</span>
                <div class="price">10.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book11.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">broke milennial</span>
                <div class="price">11.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book12.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Finish School</span>
                <div class="price">8.50$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book13.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Joy Ful</span>
                <div class="price">11.00$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book14.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">What Not to Say</span>
                <div class="price">9.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book15.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Book Human Emotion</span>
                <div class="price">11.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book16.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The Food Therapist</span>
                <div class="price">7.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book17.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The Book Of Question</span>
                <div class="price">8.50$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book18.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The Little Book Of Confidence</span>
                <div class="price">11.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book19.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">The Psychology Book</span>
                <div class="price">12.99$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book20.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Mind Set</span>
                <div class="price">10$</div>
            </div>
        </div>
        <div class="box">
            <div class="image">
                <img class= "images" src="/image/book21.jpg" alt="">
                <div class="icons">
                    <i class="fa-regular fa-star"></i>
                    <button class="shop-item-button" type="button" >Add to cart</button>
                </div>
            </div>
            <div class="content">
                <span class="product-content">Believe It To Achieve It</span>
                <div class="price">11$</div>
            </div>
        </div>
    </div>
</section>
<!--end of product section  -->

<!-- start about us -->
<section class="about" id="about">
    <div class="contents">
        <h4>our service</h4>
        <p>We are a team of passionate people whose goal is to improve everyone's life through disruptive products. We build great products to solve your business problems.
            Our products are designed for small to medium size companies willing to optimize their performance.</p>
        <span>Follow us</span>
        <div class="icon">
            <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#"><i class="fa-brands fa-youtube"></i></a>
            <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
            <a href="#"><i class="fa-brands fa-twitter"></i></a>
        </div>
    </div>
</section>
<section style="padding-top: 100px; margin-top: -100px" id="contact">
</section>


<script src="{{ asset('app.js') }}"></script>
<script src="{{ asset('/js/script.js') }}"></script>

</body>
</html>
