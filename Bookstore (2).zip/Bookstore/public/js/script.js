
if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded', ready)
}else{
    ready()
}
function ready(){
    var removeCartItemsButtons = document.getElementsByClassName("remove")
    for (var i = 0 ; i < removeCartItemsButtons.length;i++){
        var button = removeCartItemsButtons[i]
        button.addEventListener('click', removeCartItem)
    }
    var quatityInputs = document.getElementsByClassName('qt')
    for (var i = 0 ; i < quatityInputs.length;i++){
        var input = quatityInputs[i]
        input.addEventListener('change', quatityChanged)
    }
    var addtoCartButton = document.getElementsByClassName('shop-item-button')
    for (var i = 0 ; i < addtoCartButton.length;i++){
        var button = addtoCartButton[i]
        button.addEventListener('click' , addtoCartClicked)
    }
}
function removeCartItem(event){
    var buttonClicked = event.target
    buttonClicked.parentElement.parentElement.parentElement.remove()
    updateCartTotal()
}
function quatityChanged(events){
    var input = events.target
    if(isNaN(input.value) || input.value <= 0){
        input.value = 1
    }
    updateCartTotal()
}
function addtoCartClicked(event){
    var button = event.target
    var shopitem = button.parentElement.parentElement.parentElement
    var title = shopitem.getElementsByClassName('product-content')[0].innerText
    var price = shopitem.getElementsByClassName('price')[0].innerText
    var img = shopitem.getElementsByClassName('images')[0].src
    console.log(title, price, img)
    addItemToCart(title, price, img)
}
function addItemToCart(title, price, img){
    var CartRow = document.createElement('div')
    CartRow.classList.add('product')
    var Cartitem = document.getElementsByClassName('cart')[0]
    // var cartRowContent = ` 
    //     <div class="product">
    //         <header>
    //             <a class="remove">
    //                 <img src="${img}" alt="">

    //                 <h3>Remove product</h3>
    //             </a>
    //         </header>

    //         <div class="content">

    //             <h1>${title}</h1>

    //             <h5>The strength in our scars is Bianca Sparacino's reminder to you: No matter what you're going through, no matter where you are on your healing journey-you are strong.
    //                 Through poetry, prose, and the compassionate encouragement you would expect from someone who knows exactly what you're working through.</h5>
    //         </div>

    //         <footer class="content">
    //             <!-- <span class="qt-minus">-</span> -->
    //             <input class="qt" type="number" value="1">
    //             <!-- <span class="qt-plus">+</span> -->

    //             <h2 class="${price}">
    //                 14.99€
    //             </h2>

    //             <h2 class="price">
    //                 14.99€
    //             </h2>
    //         </footer>
    //     </div>`
    //         CartRow.innerHTML = cartRowContent
    Cartitem.append(CartRow)
}
function updateCartTotal() {
    var cartIdemContainer = document.getElementsByClassName('cart')[0]
    var CartRows = cartIdemContainer.getElementsByClassName('product')
    total = 0 
    for (var i = 0 ; i < CartRows.length;i++){
        var cartRow = CartRows[i]
        var priceElement = cartRow.getElementsByClassName('full-price')[0]
        var quantityElement = cartRow.getElementsByClassName('qt')[0]
        var price = parseFloat(priceElement.innerText.replace('$' , ''))
        var quatity = quantityElement.value
        total = total + (price * quatity)
    }
    total = Math.round( total * 100) / 100
    document.getElementsByClassName('total')[0].innerText = '$' + total
}



// var check = false;

// function changeVal(el) {
//     var qt = parseFloat(el.parent().children(".qt").html());
//     var price = parseFloat(el.parent().children(".price").html());
//     var eq = Math.round(price * qt * 100) / 100;

//     el.parent().children(".full-price").html( eq + "€" );

//     changeTotal();
// }

// function changeTotal() {

//     var price = 0;

//     $(".full-price").each(function(index){
//         price += parseFloat($(".full-price").eq(index).html());
//     });

//     price = Math.round(price * 100) / 100;
//     var tax = Math.round(price * 0.05 * 100) / 100
//     var shipping = parseFloat($(".shipping span").html());
//     var fullPrice = Math.round((price + tax + shipping) *100) / 100;

//     if(price == 0) {
//         fullPrice = 0;
//     }

//     $(".subtotal span").html(price);
//     $(".tax span").html(tax);
//     $(".total span").html(fullPrice);
// }

// $(document).ready(function(){

//     $(".remove").click(function(){
//         var el = $(this);
//         el.parent().parent().addClass("removed");
//         window.setTimeout(
//             function(){
//                 el.parent().parent().slideUp('fast', function() {
//                     el.parent().parent().remove();
//                     if($(".product").length == 0) {
//                         if(check) {
//                             $("#cart").html("<h1>The shop does not function, yet!</h1><p>If you liked my shopping cart, please take a second and heart this Pen on <a href='https://codepen.io/ziga-miklic/pen/xhpob'>CodePen</a>. Thank you!</p>");
//                         } else {
//                             $("#cart").html("<h1>No products!</h1>");
//                         }
//                     }
//                     changeTotal();
//                 });
//             }, 200);
//     });

//     $(".qt-plus").click(function(){
//         $(this).parent().children(".qt").html(parseInt($(this).parent().children(".qt").html()) + 1);

//         $(this).parent().children(".full-price").addClass("added");

//         var el = $(this);
//         window.setTimeout(function(){el.parent().children(".full-price").removeClass("added"); changeVal(el);}, 150);
//     });

//     $(".qt-minus").click(function(){

//         child = $(this).parent().children(".qt");

//         if(parseInt(child.html()) > 1) {
//             child.html(parseInt(child.html()) - 1);
//         }

//         $(this).parent().children(".full-price").addClass("minused");

//         var el = $(this);
//         window.setTimeout(function(){el.parent().children(".full-price").removeClass("minused"); changeVal(el);}, 150);
//     });

//     window.setTimeout(function(){$(".is-open").removeClass("is-open")}, 1200);

//     $(".btn").click(function(){
//         check = true;
//         $(".remove").click();
//     });
//     // add to cart
//     var addCart = document.getElementsByClassName('cart-btn')
//     // console.log(addCart )
//     for (var i = 0 ; i < addCart.length ; i++){
//         var button = addCart[i];
//         button.addEventListener('click' , addCartClicked);
//     }
//     // add To cart
// function addCartClicked(event){
//     var button = event.target
//     var shop = button.parentElement
//     var title = shop.getElementsByClassName('product-content')[0].innerText;
//     var price = shop.getElementsByClassName('price')[0].innerText;
//     var productimage = shop.getElementsByClassName('images')[0].src;
//     addProductTocart(title , price , productimage);
//     // updatetotal();
// }
// function addProductTocart(title , price , productimage){
//     var cartShopBox = document.createElement('div')
//     cartShopBox.classList.add('cart-box')
//     var cartItems = document.getElementsByClassName('cart-content')[0]
//     var cartItemsNames = cartItems.getElementsByClassName('cart-product-title')
//     for (var i = 0 ; i < cartItemsNames.length ; i++){
//         if (cartItemsNames[i].innerText === title){
//             alert("this item already choose");
//             return;
//         }
//     }
//     cartShopBox.innerHTML = `
//                     <img src="${productimage}" alt="" class="cart-img">
//                     <div class="detial-box">
//                         <div class="cart-product-title">${title}</div>
//                         <div class="cart-price">${price}</div>
//                         <input type="number" value="1" class="cart-quantity">
//                     </div>`
// }
// });
