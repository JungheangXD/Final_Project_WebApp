<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class Maincontroller extends Controller
{
    function login(){
        return view('Registerweb');
    }
    function save(Request $request){
       //validate request
       $request->validate([
            'name'=>'required',
            'email'=>'required|email|unique:users',
            'password'=>'required|min:5|max:12'
       ]);
       //insert data to databse
       $admin = new User;
       $admin->name = $request->name;
       $admin->email = $request->email;
       $admin->password = Hash::make($request->password);
       $save = $admin->save();

       if($save){
        // return back()->with('Successfully create account');
        return redirect('/payment');
       }else{
        return back()->with('fail','Something went wrong, try again');
       }
    }
    function check(Request $request){
        // validate request
        // return $request->input();
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:5|max:12'
        ]);

        $userInfo = User::where('email','=',$request->email)->first();
        if(!$userInfo){
            return back()->with('fail','We do recognize your email address');
        }else{
            //check password
            if(Hash::check($request->password,$userInfo->password)){
                
                 ($request->session()->put('Logged', $userInfo->id));
                return redirect('/payment');
            }else{
                return back()->with('fail','Incorrect password');
            }
        }
    }
    function payment(){
        return view('payment');
    }
}
