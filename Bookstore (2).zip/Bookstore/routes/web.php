<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Maincontroller;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//direct the user to the login/register interface
// Route::get('/register', function () {
//     return view('Registerweb');
// })->name('register');

Route::get ('/shoppingcart', function(){
    return view ('ShoppingCart');
})->name('shoppingcart');


Route::get('/welcome', function () {
    return view('welcome');
})->name('welcome');

Route::get('/Registerweb',[Maincontroller::class, 'login'])->name('Registerweb');
Route::post('/save',[Maincontroller::class, 'save'])->name('save');
Route::post('/check',[Maincontroller::class, 'check'])->name('check');

Route::get('/payment',[Maincontroller::class, 'payment'])->name('payment');

Route::get ('/displaypopup', function(){
    return view ('displaypopup');
})->name('displaypopup');
// Route::get('/displaypopup',[Maincontroller::class, 'displaypopup'])->name('displaypopup');